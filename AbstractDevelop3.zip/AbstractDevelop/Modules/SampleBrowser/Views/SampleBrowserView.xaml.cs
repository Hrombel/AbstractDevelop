﻿using System.Windows.Controls;

namespace AbstractDevelop.Modules.SampleBrowser.Views
{
    public partial class SampleBrowserView : UserControl
    {
        public SampleBrowserView()
        {
            InitializeComponent();
        }
    }
}
