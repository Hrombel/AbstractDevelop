﻿namespace Gemini.Demo.Modules.Home.ViewModels
{
    public interface IDemoScript
    {
        void Execute(HelixViewModel viewModel);
    }
}