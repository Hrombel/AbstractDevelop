﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.IO;
using System.Threading.Tasks;
using AbstractDevelop.Modules.TextEditor.ViewModels;
using Gemini.Framework;
using Gemini.Framework.Services;
using AbstractDevelop.Properties;

namespace AbstractDevelop.Modules.TextEditor
{
	[Export(typeof(IEditorProvider))]
	public class EditorProvider : IEditorProvider
	{
		private readonly List<string> _extensions = new List<string>
        {
            ".txt",
            ".cmd"
        };

        public IEnumerable<EditorFileType> FileTypes
        {
            get { yield return new EditorFileType(Resources.EditorProviderTextFile, ".txt"); }
        }

		public bool Handles(string path)
		{
			var extension = Path.GetExtension(path);
			return _extensions.Contains(extension);
		}

        public IDocument Create()
        {
            return new EditorViewModel();
        }

        public async Task New(IDocument document, string name)
        {
            await ((EditorViewModel) document).New(name);
        }

        public async Task Open(IDocument document, string path)
		{
			await ((EditorViewModel) document).Load(path);
		}
	}
}