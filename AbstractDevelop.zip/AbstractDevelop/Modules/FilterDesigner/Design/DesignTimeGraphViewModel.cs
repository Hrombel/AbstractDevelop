﻿using Gemini.Demo.Modules.FilterDesigner.ViewModels;

namespace Gemini.Demo.Modules.FilterDesigner.Design
{
    public class DesignTimeGraphViewModel : GraphViewModel
    {
        public DesignTimeGraphViewModel()
            : base(null)
        {
            
        }
    }
}