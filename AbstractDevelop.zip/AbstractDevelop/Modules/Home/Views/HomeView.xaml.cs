﻿using System.Windows.Controls;

namespace Gemini.Demo.Modules.Home.Views
{
	/// <summary>
	/// Interaction logic for HomeView.xaml
	/// </summary>
	public partial class HomeView : UserControl
	{
		public HomeView()
		{
			InitializeComponent();
		}
	}
}
