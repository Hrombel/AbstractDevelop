﻿namespace Gemini.Demo.Modules.Home.Views
{
    public interface IHelixView
    {
        ICSharpCode.AvalonEdit.TextEditor TextEditor { get; }  
    }
}